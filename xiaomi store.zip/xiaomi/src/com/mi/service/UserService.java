package com.mi.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.mi.domain.PageBean;
import com.mi.domain.User;

public interface UserService {
	public User checkPhoneNumber(String phone_number);
	public void register(User user);
	public String login(String phone_number, String code, HttpServletRequest request);
	public User adminLogin(String username, String password);
	public List<User> selectUlist();
	public void updateRole(String manager, String uid);
	public void batchDelete(String ids);
	public PageBean<User> selectUlistByPage(PageBean pb);
	
}
