package com.mi.service.impl;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.mi.dao.UserDao;
import com.mi.dao.impl.UserDaoImpl;
import com.mi.domain.PageBean;
import com.mi.domain.User;
import com.mi.service.UserService;

public class UserServiceImpl implements UserService {

	private UserDao ud = new UserDaoImpl();
	@Override
	public User checkPhoneNumber(String phone_number) {
		return ud.checkPhoneNumber(phone_number);
	}
	@Override
	public void register(User user) {
		ud.register(user);
	}
	@Override
	public String login(String phone_number, String code, HttpServletRequest request) {
		//1、验证码不一致
			 //获取session中的验证码
		String sessionCode = (String) request.getSession().getAttribute("code");
		if(code !=null && (phone_number+code).equals(sessionCode)) {
			
			User user = ud.checkPhoneNumber(phone_number);
			if(user != null) {
				//3、登录成功
				return "2";
			}else {
				//2、手机号未注册
				return "1";
			}
		}else {
			//返回结果是：0
			return "0";
		}
		
	}
	@Override
	public User adminLogin(String username, String password) {
		// TODO Auto-generated method stub
		return ud.adminLogin(username,password);
	}
	@Override
	public List<User> selectUlist() {
		// TODO Auto-generated method stub
		return ud.selectUlist();
	}
	@Override
	public void updateRole(String manager, String uid) {
		ud.updateRole(manager,uid);
	}
	@Override
	public void batchDelete(String ids) {
		ud.batchDelete(ids);
	}
	@Override
	public PageBean<User> selectUlistByPage(PageBean pb) {
		//查询某一页的数据
		List<User> result = ud.selectUlistByPage(pb);
		pb.setResult(result);
		//查询总记录数
		Integer count = (int) ud.selectCount();
		pb.setTotalCount(count);
		return pb;
	}

}
