package com.mi.service.impl;

import java.util.List;

import com.mi.dao.CategoryDao;
import com.mi.dao.ProductDao;
import com.mi.dao.impl.CategoryDaoImpl;
import com.mi.dao.impl.ProductDaoImpl;
import com.mi.domain.Category;
import com.mi.domain.PageBean;
import com.mi.domain.Product;
import com.mi.service.ProductService;

public class ProductServiceImpl implements ProductService {
	private ProductDao pd = new ProductDaoImpl();
	private CategoryDao cd = new CategoryDaoImpl();
	public PageBean<Product> selectPlistByPage(PageBean pb,Product product) {
		//查出每一页封装List的数据
		List<Product> result = pd.selectPlistByPage(pb,product);
		for(Product p:result) {
			//获取商品所属的cid
			int cid = p.getCid();
			//根据cid查询商品的分类
			Category category = cd.selectCategoryByCid(cid+"");
			p.setCategory(category);
			
		}
		pb.setResult(result);
		//查询总记录数
		int count = pd.selectCount(product);
		pb.setTotalCount(count);
		return pb;
	}
	@Override
	public void addProduct(Product p) {
		pd.addProduct(p);
	}
}
