package com.mi.service.impl;

import java.util.List;

import com.mi.dao.CategoryDao;
import com.mi.dao.impl.CategoryDaoImpl;
import com.mi.domain.Category;
import com.mi.domain.PageBean;
import com.mi.service.CategoryService;

public class CategoryServiceImpl implements CategoryService {
	private CategoryDao cd = new CategoryDaoImpl();

	@Override
	public PageBean<Category> selectClistByPage(PageBean pb) {
		//查出每一页封装List的数据
		List<Category> result = cd.selectClistByPage(pb);
		pb.setResult(result);
		//查询总记录数
		int count = cd.selectCount();
		pb.setTotalCount(count);
		return pb;
	}

	@Override
	public void addCategory(Category category) {
		cd.addCategory(category);
	}

	@Override
	public Category selectCategoryByCid(String cid) {
		// TODO Auto-generated method stub
		return cd.selectCategoryByCid(cid);
	}

	@Override
	public void updateCategory(Category category) {
		cd.updateCategory(category);
	}

	@Override
	public void deleteByCid(String cid) {
		cd.deleteByCid(cid);
	}

	@Override
	public List<Category> selectClist() {
		// TODO Auto-generated method stub
		return cd.selectClist();
	}

}
