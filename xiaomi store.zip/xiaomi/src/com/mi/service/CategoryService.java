package com.mi.service;

import java.util.List;

import com.mi.domain.Category;
import com.mi.domain.PageBean;

public interface CategoryService {

	PageBean<Category> selectClistByPage(PageBean pb);

	void addCategory(Category category);

	Category selectCategoryByCid(String cid);

	void updateCategory(Category category);
	void deleteByCid(String cid);

	List<Category> selectClist();

}
