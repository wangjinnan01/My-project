package com.mi.service;

import com.mi.domain.Category;
import com.mi.domain.PageBean;
import com.mi.domain.Product;

public interface ProductService {
	
	public PageBean<Product> selectPlistByPage(PageBean pb, Product p);

	public void addProduct(Product p);

}
