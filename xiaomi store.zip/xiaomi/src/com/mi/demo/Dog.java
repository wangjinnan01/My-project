package com.mi.demo;

public class Dog extends Animal{
	
	public String dname;
	private int age;
	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
	//公共的方法
	public void eat() {
		System.out.println("狗啃骨头");
	}
	//私有
	private void play() {
		System.out.println("狗玩游戏！！");
	}
	
	public void add(int i,int j) {
		System.out.println("两个数字之和为："+(i+j));
	}
	//公共的构造方法
	public Dog(String dname, int age) {
		super();
		this.dname = dname;
		this.age = age;
	}
	//私有的构造方法
	private Dog(String dname) {
		super();
		this.dname = dname;
	}
	@Override
	public String toString() {
		return "Dog [dname=" + dname + ", age=" + age + "]";
	}
	public Dog() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	

}
