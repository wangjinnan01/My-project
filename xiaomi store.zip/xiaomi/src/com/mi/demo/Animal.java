package com.mi.demo;

public class Animal {
	
	public void sing() {
		System.out.println("Anima在唱歌");
		this.eat();//当前对象
	}
	public void eat() {
		System.out.println("Anima吃东西！");
	}
	
	
	public static void main(String[] args) {
		Animal dog= new Dog();
		dog.sing();
	}

}
