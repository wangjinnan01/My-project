package com.mi.demo;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Date;

import org.junit.Test;

public class TestDog {
	
	/*public static void main(String[] args) {
		//原始：
		//1、创建对象
		Dog dog1 = new Dog("阿黄",2);
		System.out.println(dog1);
		//Dog dog2 = new Dog("阿绿");
		//2、操作属性
		   dog1.setDname("阿绿");
		   dog1.setAge(5);
		   System.out.println(dog1);
		//3、操作方法
		   dog1.eat();
	}*/
	
	public static void main(String[] args) throws Exception {
		//反射
		//Dog dog1 = new Dog("阿黄",2);
		   //获取该类的字节码Class
		//  Class clazz1 =  Dog.class;
		  //Class clazz2 = dog1.getClass();
		  Class clazz3 = Class.forName("com.mi.demo.Dog");
		  //System.out.println(clazz1 == clazz3);
		//1、创建对象
		  	//获取构造对象
		    Constructor con1 = clazz3.getDeclaredConstructor(String.class,int.class);
		    //创建对象
		    Dog dog = (Dog) con1.newInstance("小白",3);
		    System.out.println(dog);
		    //获取私有的构造方法
		    Constructor con2 =   clazz3.getDeclaredConstructor(String.class);
		    //创建对象
		     //暴力反射
		    con2.setAccessible(true);
		    Dog dog2 = (Dog)con2.newInstance("小黑");
		    System.out.println(dog2);
		//2、操作属性
		    Field field1 = clazz3.getDeclaredField("dname");
		    field1.set(dog2, "小花");
		    System.out.println(dog2);
		    Field field2 = clazz3.getDeclaredField("age");
		    //暴力反射
		    field2.setAccessible(true);
		    field2.set(dog2, 11);
		    System.out.println(dog2);
		//3、操作方法
		    Method method1 = clazz3.getDeclaredMethod("eat");
		    method1.invoke(dog2);
		    
		    Method method2 = clazz3.getDeclaredMethod("play");
		    method2.setAccessible(true);
		    method2.invoke(dog2);
		    
		    Method method3 = clazz3.getDeclaredMethod("add",int.class,int.class);
		    method3.invoke(dog2,11,12);
	}

	@Test
	public void test1() {
		System.out.println(new Date().toLocaleString());
	}
}
