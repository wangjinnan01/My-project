package com.mi.web.base;

import java.io.IOException;
import java.lang.reflect.Method;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class BaseServlet extends HttpServlet{

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    try {
	    	
	    	//获取请求方法的参数
	    	String method = request.getParameter("method");
	    	//反射
	    	//1、获取该类的字节码文件
	    	Class clazz =  this.getClass();
	    	//2、根据方法名获取对应的方法对象
			Method m = clazz.getDeclaredMethod(method, HttpServletRequest.class,HttpServletResponse.class);
		    //3、执行方法
			String path = (String) m.invoke(this, request,response);
			//4、请求转发到path
			if(path != null && !"".equals(path)) {
				//请求转发
				request.getRequestDispatcher(path+".jsp").forward(request, response);;
			}
	    } catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	/*if("register".equals(method)) {
		//调用注册方法
		register(request, response);
	}else if("login".equals(method)) {
		//调用登录方法
		login(request, response);
	}else if("logout".equals(method)) {
		//调用注销方法
		logout(request, response);
	}else if("active".equals(method)) {
		//调用激活方法
		active(request, response);
	}else {
		System.out.println("没有此方法");
	}*/
}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
}
