package com.mi.web.filter;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mi.domain.User;

/**
 * 
 */
@WebFilter("/admin/*")
public class LoginFilter implements Filter {

	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		//判断是否登录

		HttpServletRequest req = (HttpServletRequest) request;
		HttpServletResponse resp = (HttpServletResponse) response;
		//放行访问登录页面
		String uri = req.getRequestURI();
		System.out.println(uri);
		if(uri.contains("/login.jsp") || uri.contains("/css") || uri.contains("/images")
				|| uri.contains("/js")) {
			//放行
			chain.doFilter(request, response);
			return;
		}
		User user = (User) req.getSession().getAttribute("user");
		 //没有登录(拦截跳转到登录页面)
		if(user == null) {
			resp.sendRedirect(req.getContextPath()+"/admin/login.jsp");
			return;
		}else {
			 //登录   放行
			chain.doFilter(request, response);
		}
		  
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
