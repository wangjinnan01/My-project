package com.mi.web.servlet;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import org.apache.commons.beanutils.BeanUtils;

import com.mi.domain.Product;
import com.mi.domain.Category;
import com.mi.domain.PageBean;
import com.mi.service.CategoryService;
import com.mi.service.ProductService;
import com.mi.service.impl.CategoryServiceImpl;
import com.mi.service.impl.ProductServiceImpl;
import com.mi.web.base.BaseServlet;
@WebServlet("/product")
@MultipartConfig
public class ProductServlet extends BaseServlet{
	
	
	public String addProduct(HttpServletRequest request,HttpServletResponse response)throws ServletException, IOException {
		
		try {
			Map<String, String[]> map = request.getParameterMap();
			Product p = new Product();
			BeanUtils.populate(p, map);
			//获取图片
			Part part = request.getPart("pic");
			//获取图片名称
			String headerValue = part.getHeader("Content-Disposition");
			String fileName = headerValue.substring(headerValue.indexOf("filename")+10, headerValue.length()-1);
			
			//上传到指定位置
			String path = "E:\\java\\xm_upload";
			part.write(path + "/" + fileName);
			ProductService ps = new ProductServiceImpl();
			p.setPic(fileName);
			ps.addProduct(p);
			
			response.sendRedirect(request.getContextPath()+"/product?method=selectPlistByPage&pageNumber=1");
			
		} catch (IllegalAccessException | InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "/admin/product_add";
	}
	
	public String toAddProduct(HttpServletRequest request,HttpServletResponse response)throws ServletException, IOException {
		//查询所有分类
		CategoryService cs = new CategoryServiceImpl();
		
		List<Category> clist = cs.selectClist();
		request.setAttribute("clist", clist);
		return "/admin/product_add";
	}
	
	//分类的分页查询
	public String selectPlistByPage(HttpServletRequest request,HttpServletResponse response)throws ServletException, IOException {
		//获取当前页
		String pageNumber = request.getParameter("pageNumber");
		   //获取商品名称
			String pname = request.getParameter("pname");
		   //获取state
			String state = request.getParameter("state");
		   //获取起始时间
			String start_time = request.getParameter("start_time");
		   //获取结束时间
			String end_time = request.getParameter("end_time");
			//创建Product对象
			Product p = new Product();
			p.setPname(pname);
			if(state != null) {
			p.setState(Integer.parseInt(state));
			}
			p.setStart_time(start_time);
			p.setEnd_time(end_time);
		PageBean pb = new PageBean();
		pb.setPageNumber(Integer.parseInt(pageNumber));
		pb.setPageSize(4);
		//调用业务层
		ProductService cs = new ProductServiceImpl();
		PageBean<Product> pageBean =  cs.selectPlistByPage(pb,p);
		request.setAttribute("pb", pageBean);
		request.setAttribute("p", p);
		return "/admin/product_list";
	}
}
