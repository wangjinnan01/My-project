package com.mi.web.servlet;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import org.apache.commons.beanutils.BeanUtils;

import com.mi.domain.PageBean;
import com.mi.domain.User;
import com.mi.service.UserService;
import com.mi.service.impl.UserServiceImpl;
import com.mi.utils.SMSTools;
import com.mi.utils.UUIDUtils;
import com.mi.web.base.BaseServlet;

@WebServlet("/user")
@MultipartConfig
public class UserServlet extends BaseServlet{
	
	//分页查询
	public String selectUlistByPage(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//获取当前页
		String pageNumber = request.getParameter("pageNumber");
		PageBean pb = new PageBean();
		pb.setPageNumber(Integer.parseInt(pageNumber));
		UserService us = new UserServiceImpl();
		PageBean<User> pageBean = us.selectUlistByPage(pb);
		request.setAttribute("pb", pageBean);
		return "/admin/user_list";
	}
	//批量删除
	public String batchDelete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//获取ids
		String ids = request.getParameter("ids");
		UserService us = new UserServiceImpl();
		us.batchDelete(ids);
		//跳转 (重新查询数据库)
		response.sendRedirect(request.getContextPath()+"/user?method=selectUlist");
		return "";
	}
	//修改权限
	public String updateRole(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//获取manager 和 uid
		String manager = request.getParameter("manager");
		String uid = request.getParameter("uid");
		UserService us = new UserServiceImpl();
		us.updateRole(manager,uid);
		//跳转 (重新查询数据库)
		response.sendRedirect(request.getContextPath()+"/user?method=selectUlistByPage&pageNumber=1");
		return "";
	}
	
	//查询所有用户
	public String selectUlist(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		UserService us = new UserServiceImpl();
		List<User> ulist = us.selectUlist();
		request.setAttribute("ulist", ulist);
		return "/admin/user_list";
	}

	//管理员退出
	public void logout(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.getSession().removeAttribute("user");
		//重定向到登录页面
	//	response.sendRedirect(request.getContextPath()+"/admin/login.jsp");
	}

	
	//管理员登录
	public String adminLogin(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//获取用户名、密码
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		//调用业务层
		UserService us = new UserServiceImpl();
		User user = us.adminLogin(username,password);
		if(user != null) {
			//登录成功
			//将用户信息存到session中
			request.getSession().setAttribute("user", user);
			//重定向
			response.sendRedirect(request.getContextPath()+"/admin/main.jsp");
			
			return null;
		}
		else {
			request.setAttribute("msg", "用户名或者密码不正确/不是管理员");
			return "/admin/login";
		}
	}
	
	//用户登录
	public void login(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//获取手机号
		String phone_number = request.getParameter("phone_number");
		//获取验证码
		String code= request.getParameter("code");
		//调用业务层
		UserService us = new UserServiceImpl();
		String msg = us.login(phone_number,code,request);
		//将结果响应给浏览器
		response.getWriter().write(msg);
	}
	
	//发送验证码
	public void sendCode(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//获取手机号
		String phone_number = request.getParameter("phone_number");
		//调用工具类发送
		//SMSTools.sendCode(phone_number);
		//获取四位随机数
		long code = (long) (Math.random()*(9999-1000)+1000);
		System.out.println("您的验证码为："+code+"，五分钟有效，请勿泄露给他人！！！");
		request.getSession().setAttribute("code", phone_number+code+"");
	}
	
	//用户注册
	public void register(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			//获取数据
			Map<String, String[]> map = request.getParameterMap();
			User user = new User();
			BeanUtils.populate(user, map);
			//注册时间
			user.setCreate_time(new Date().toLocaleString());
			//头像问题
			Part part = request.getPart("photo");
			//获取图片的名称
			String headerValue =part.getHeader("Content-Disposition");
			System.out.println(headerValue);
			//headerValue.substring(beginIndex, endIndex)
			//form-data; name="photo"; filename="wukong.jpg"
			//filename所在的索引位置
			String fileName = headerValue.substring(headerValue.indexOf("filename")+10, headerValue.length()-1);
			System.out.println(fileName);
			fileName = UUIDUtils.getUUID()+fileName;
			//获取upload的文件路径
			//String path = request.getServletContext().getRealPath("/upload");
			//修改上传路径为本地
			String path  = "E:\\java\\xm_upload";
			System.out.println(path);
			//上传到指定的位置
			part.write(path+"/"+fileName);
			//设置user的photo字段
			user.setPhoto(fileName);
			//调用业务
			UserService us = new UserServiceImpl();
			us.register(user);
			//结果展示
			//跳转到登录页面
			response.getWriter().write("<h2>注册成功！！3秒后跳转到登录页面！！</h2>");
			response.setHeader("refresh", "3;url=/xiaomi/login.jsp");
		} catch (IllegalAccessException | InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	//校验手机号唯一
	public void checkPhoneNumber(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//获取手机号
		String phone_number = request.getParameter("phone_number");
		//调用service
		UserService us = new UserServiceImpl();
		User user = us.checkPhoneNumber(phone_number);
		String msg = "";
		//结果展示
		if(user != null) {
			msg = "false";
		}else {
			msg = "true";
		}
		response.getWriter().write(msg);
	}
	
	

}
