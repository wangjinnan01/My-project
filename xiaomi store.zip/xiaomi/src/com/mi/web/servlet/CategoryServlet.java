package com.mi.web.servlet;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;

import com.mi.domain.Category;
import com.mi.domain.PageBean;
import com.mi.service.CategoryService;
import com.mi.service.impl.CategoryServiceImpl;
import com.mi.web.base.BaseServlet;
@WebServlet("/category")
public class CategoryServlet extends BaseServlet{
	
	//根据cid删除
	
	public String deleteByCid(HttpServletRequest request,HttpServletResponse response)throws ServletException, IOException {
		String cid = request.getParameter("cid");
		CategoryService cs = new CategoryServiceImpl();
		cs.deleteByCid(cid);
		response.sendRedirect(request.getContextPath()+"/category?method=selectClistByPage&pageNumber=1");
		return null;
		
	}
	//修改分类
	public String updateCategory(HttpServletRequest request,HttpServletResponse response)throws ServletException, IOException {
		try {
			Map<String, String[]> map = request.getParameterMap();
			Category category = new Category();
			BeanUtils.populate(category, map);
			//调用业务层
			CategoryService cs = new CategoryServiceImpl();
			cs.updateCategory(category);
			
			response.sendRedirect(request.getContextPath()+"/category?method=selectClistByPage&pageNumber=1");
		} catch (IllegalAccessException | InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		return "";
	}
	
	//跳转到修改分类的页面
	public String toUpdateCategory(HttpServletRequest request,HttpServletResponse response)throws ServletException, IOException {
		//根据cid将分类查出
		String cid = request.getParameter("cid");
		CategoryService cs = new CategoryServiceImpl();
		Category categroy  = cs.selectCategoryByCid(cid);
		request.setAttribute("category", categroy);
		return "/admin/category_update";
	}
	//添加分类
	public String addCategory(HttpServletRequest request,HttpServletResponse response)throws ServletException, IOException {
		try {
			Map<String, String[]> map = request.getParameterMap();
			Category category = new Category();
			BeanUtils.populate(category, map);
			//调用业务层
			CategoryService cs = new CategoryServiceImpl();
			cs.addCategory(category);
			
			response.sendRedirect(request.getContextPath()+"/category?method=selectClistByPage&pageNumber=1");
		} catch (IllegalAccessException | InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		return "";
	}

	//分类的分页查询
	public String selectClistByPage(HttpServletRequest request,HttpServletResponse response)throws ServletException, IOException {
		//获取当前页
		String pageNumber = request.getParameter("pageNumber");
		PageBean pb = new PageBean();
		pb.setPageNumber(Integer.parseInt(pageNumber));
		pb.setPageSize(4);
		//调用业务层
		CategoryService cs = new CategoryServiceImpl();
		PageBean<Category> pageBean =  cs.selectClistByPage(pb);
		request.setAttribute("pb", pageBean);
		return "/admin/category_list";
	}
}
