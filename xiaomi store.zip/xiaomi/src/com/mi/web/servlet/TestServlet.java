package com.mi.web.servlet;

import java.io.IOException;
import java.lang.reflect.Method;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mi.web.base.BaseServlet;

/**
 * Servlet implementation class TestServlet
 */
@WebServlet("/test")
public class TestServlet extends BaseServlet {
	
	
	public void active(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("用户激活");
	}
	public void logout(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("用户注销");
	}
	public void login(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("用户登录");
		//t
	}
	public String register(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("用户注册");
		
		return "login";
	}

	

}
