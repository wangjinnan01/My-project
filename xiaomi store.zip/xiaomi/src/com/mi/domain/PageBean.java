package com.mi.domain;

import java.io.Serializable;
import java.util.List;

public class PageBean<T> implements Serializable{

	private Integer pageNumber;//当前页
	private Integer startIndex;//起始索引
	private Integer pageSize = 3;//每页显示的条数
	private Integer totalCount;//总记录数
	private Integer totalPage;//总页数
	private List<T> result;//一页的数据
	public Integer getPageNumber() {
		return pageNumber;
	}
	public void setPageNumber(Integer pageNumber) {
		this.pageNumber = pageNumber;
	}
	public Integer getStartIndex() {
		return startIndex = (getPageNumber() - 1) * getPageSize();
	}
	public void setStartIndex(Integer startIndex) {
		this.startIndex = startIndex;
	}
	public Integer getPageSize() {
		return pageSize;
	}
	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}
	public Integer getTotalCount() {
		return totalCount;
	}
	public void setTotalCount(Integer totalCount) {
		this.totalCount = totalCount;
	}
	public Integer getTotalPage() {
		return totalPage = (getTotalCount() % getPageSize() == 0 ? getTotalCount()/getPageSize()
				:(getTotalCount() / getPageSize() +1));
	}
	public void setTotalPage(Integer totalPage) {
		this.totalPage = totalPage;
	}
	public List<T> getResult() {
		return result;
	}
	public void setResult(List<T> result) {
		this.result = result;
	}
	public PageBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
	
	
}
