package com.mi.domain;

import java.io.Serializable;
/*`cid` INT(10) PRIMARY KEY AUTO_INCREMENT,
`cname` VARCHAR(50) NOT NULL,
`state` INT(1) DEFAULT NULL,
`order_number` INT(5) DEFAULT NULL,
`description` VARCHAR(100) DEFAULT NULL,
`create_time` DATETIME*/
public class Category implements Serializable{
	
	private int cid;//主键id
	private String cname;//分类名称
	private int state;//是否启用   1：启用   0：不启用
	private int order_number;//排序号
	private String description;//分类描述
	private String create_time;//创建时间
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public int getState() {
		return state;
	}
	public void setState(int state) {
		this.state = state;
	}
	public int getOrder_number() {
		return order_number;
	}
	public void setOrder_number(int order_number) {
		this.order_number = order_number;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getCreate_time() {
		return create_time;
	}
	public void setCreate_time(String create_time) {
		this.create_time = create_time;
	}
	public Category() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	

}
