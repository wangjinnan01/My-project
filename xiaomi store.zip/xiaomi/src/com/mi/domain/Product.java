package com.mi.domain;

import java.io.Serializable;

public class Product implements Serializable{

	/*`pid` INT(10) PRIMARY KEY AUTO_INCREMENT,
	  `pname` VARCHAR(50) NOT NULL,
	  `color` VARCHAR(50),
	  `price` DOUBLE NOT NULL,
	  `description` VARCHAR(500),
	  `pic` VARCHAR(200),
	  `state` INT(5) DEFAULT '0',
	  `version` VARCHAR(50),
	  `product_date` DATETIME,
	   cid INT(10)*/
	private int pid;//主键id
	private String pname;//商品名称
	private String color;//商品颜色
	private double price;//商品价格
	private String description;//商品描述
	private String pic;//商品图片
	private int state;//0:普通 1：热门商品  2：为你推荐   3：新品  4：小米明星单品
	private String version;//版本号
	private String product_date;//生产日期
	private int cid;//分类的id
	private Category category;
	private String start_time;
	private String end_time;
	
	
	public String getStart_time() {
		return start_time;
	}
	public void setStart_time(String start_time) {
		this.start_time = start_time;
	}
	public String getEnd_time() {
		return end_time;
	}
	public void setEnd_time(String end_time) {
		this.end_time = end_time;
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getPic() {
		return pic;
	}
	public void setPic(String pic) {
		this.pic = pic;
	}
	public int getState() {
		return state;
	}
	public void setState(int state) {
		this.state = state;
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	public String getProduct_date() {
		return product_date;
	}
	public void setProduct_date(String product_date) {
		this.product_date = product_date;
	}
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Category getCategory() {
		return category;
	}
	public void setCategory(Category category) {
		this.category = category;
	}
	
	
	
}
