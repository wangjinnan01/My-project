package com.mi.dao;

import java.util.List;

import com.mi.domain.Category;
import com.mi.domain.PageBean;
import com.mi.domain.Product;

public interface ProductDao {

	List<Product> selectPlistByPage(PageBean pb, Product product);

	int selectCount(Product p);

	void addProduct(Product p);
	

}
