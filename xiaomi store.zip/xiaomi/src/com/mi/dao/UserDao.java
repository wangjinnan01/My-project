package com.mi.dao;

import java.util.List;

import com.mi.domain.PageBean;
import com.mi.domain.User;

public interface UserDao {
	
	/*//保存用户
	void saveUser();
	//修改用户
	void updateUser();
	//根据id删除
	void deleteByUid(int id);
	void deleteByUsername(String username);
	//根据id查询
	 * 
*/
	//校验手机号码唯一
	public User checkPhoneNumber(String phone_number);
	//注册用户
	public void register(User user);
	public User adminLogin(String username, String password);
	//查询所有用户
	public List<User> selectUlist();
	public void updateRole(String manager, String uid);
	//批量删除
	public void batchDelete(String ids);
	public List<User> selectUlistByPage(PageBean pb);
	public long selectCount();
}
