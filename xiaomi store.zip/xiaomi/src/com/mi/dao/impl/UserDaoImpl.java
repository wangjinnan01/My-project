package com.mi.dao.impl;

import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import com.mi.dao.UserDao;
import com.mi.domain.PageBean;
import com.mi.domain.User;
import com.mi.utils.C3p0Utils;

public class UserDaoImpl implements UserDao {

	
	@Override
	public User checkPhoneNumber(String phone_number) {
		QueryRunner qr = new QueryRunner(C3p0Utils.getDataSource());
		String sql = "select * from user where phone_number = ?";
		try {
			return qr.query(sql, new BeanHandler<>(User.class),phone_number);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public void register(User user) {
		QueryRunner qr = new QueryRunner(C3p0Utils.getDataSource());
		String sql = "insert into user values(?,?,?,?,?,?,?,?,?,?)";
		Object [] param = {null,user.getName(),user.getSex(),user.getPhone_number(),user.getArea(),
				user.getManager(),user.getUsername(),user.getPassword(),user.getPhoto(),user.getCreate_time()};
		try {
			qr.update(sql, param);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public User adminLogin(String username, String password) {
		QueryRunner qr = new QueryRunner(C3p0Utils.getDataSource());
		String sql = "select * from user where username = ? and password = ? and manager = ?";
		Object [] param = {username,password,1};
		try {
			return qr.query(sql, new BeanHandler<>(User.class),param);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public List<User> selectUlist() {
		QueryRunner qr = new QueryRunner(C3p0Utils.getDataSource());
		String sql = "select * from user";
		try {
			return qr.query(sql, new BeanListHandler<>(User.class));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public void updateRole(String manager, String uid) {
		QueryRunner qr = new QueryRunner(C3p0Utils.getDataSource());
		String sql = "update user set manager = ? where uid = ?";
		Object [] param = {manager,uid};
		try {
			qr.update(sql, param);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void batchDelete(String ids) {
		QueryRunner qr = new QueryRunner(C3p0Utils.getDataSource());
		String sql = "delete from user where uid in ("+ids+")";
		try {
			qr.update(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public List<User> selectUlistByPage(PageBean pb) {
		QueryRunner qr = new QueryRunner(C3p0Utils.getDataSource());
		String sql = "select * from user limit ?,?";
		Object param [] = {pb.getStartIndex(),pb.getPageSize()};
		try {
			return qr.query(sql, new BeanListHandler<>(User.class),param);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
	@Override
	public long selectCount() {
		QueryRunner qr = new QueryRunner(C3p0Utils.getDataSource());
		String sql = "select count(*) from user";
		
		try {
			return (long) qr.query(sql, new ScalarHandler());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0;
		}
	}

  
}
