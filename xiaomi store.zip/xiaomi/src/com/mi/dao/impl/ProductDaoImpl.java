package com.mi.dao.impl;

import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import com.mi.dao.ProductDao;
import com.mi.domain.Category;
import com.mi.domain.PageBean;
import com.mi.domain.Product;
import com.mi.utils.C3p0Utils;

public class ProductDaoImpl implements ProductDao {

	@Override
	public List<Product> selectPlistByPage(PageBean pb,Product p) {
		QueryRunner qr = new QueryRunner(C3p0Utils.getDataSource());
		
		StringBuffer sb = new StringBuffer();
		sb.append("select * from product where 1 = 1");
		//条件查询
		if(p.getPname() != null && !"".equals(p.getPname())) {
			//根据商品名称进行模糊查询
			sb.append(" and pname like '%"+p.getPname()+"%'");
		}
		if(p.getState() != 0) {
			//根据state进行查询
			sb.append(" and state ="+p.getState());
		}
		if(p.getStart_time() != null && !"".equals(p.getStart_time()) && p.getEnd_time() != null
				&& !"".equals(p.getEnd_time())) {
			sb.append(" and product_date between '"+p.getStart_time()+"' and '"+p.getEnd_time()+"'");
		}
		//分页
		sb.append(" limit "+pb.getStartIndex()+","+pb.getPageSize()+"");
		try {
			return qr.query(sb.toString(), new BeanListHandler<>(Product.class));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public int selectCount(Product p) {
		QueryRunner qr = new QueryRunner(C3p0Utils.getDataSource());
		StringBuffer sb = new StringBuffer();
		sb.append("select count(*) from product where 1 = 1");
		//条件查询
		if(p.getPname() != null && !"".equals(p.getPname())) {
			//根据商品名称进行模糊查询
			sb.append(" and pname like '%"+p.getPname()+"%'");
		}
		if(p.getState() != 0) {
			//根据state进行查询
			sb.append(" and state ="+p.getState());
		}
		if(p.getStart_time() != null && !"".equals(p.getStart_time())  
				&& p.getEnd_time() != null && !"".equals(p.getEnd_time())) {
			sb.append(" and product_date between '"+p.getStart_time()+"' and '"+p.getEnd_time()+"'");
		}
		try {
			Long count = (Long) qr.query(sb.toString(), new ScalarHandler());
			return count.intValue();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0;
		}
	}

	@Override
	public void addProduct(Product p) {
		QueryRunner qr = new QueryRunner(C3p0Utils.getDataSource());
		String sql = "insert into product values(?,?,?,?,?,?,?,?,?,?)";
		Object [] param = {null,p.getPname(),p.getColor(),p.getPrice(),p.getDescription(),
				p.getPic(),p.getState(),p.getVersion(),p.getProduct_date(),p.getCid()};
		try {
			qr.update(sql, param);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	

}
