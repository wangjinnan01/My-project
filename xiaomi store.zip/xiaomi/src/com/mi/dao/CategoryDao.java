package com.mi.dao;

import java.util.List;

import com.mi.domain.Category;
import com.mi.domain.PageBean;

public interface CategoryDao {

	List<Category> selectClistByPage(PageBean pb);

	int selectCount();

	void addCategory(Category category);

	Category selectCategoryByCid(String cid);

	void updateCategory(Category category);
	
	//根据cid删除
	void deleteByCid(String cid);

	List<Category> selectClist();

}
